//
//  CollectionCellView.swift
//  TutorialSample
//
//  Created by Drish on 08/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit

class CollectionCellView: UICollectionViewCell {
    
    @IBOutlet var introImage: UIImageView!
}
