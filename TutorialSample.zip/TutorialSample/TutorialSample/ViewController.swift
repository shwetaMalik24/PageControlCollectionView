//
//  ViewController.swift
//  TutorialSample
//
//  Created by Drish on 08/06/20.
//  Copyright © 2020 Drish. All rights reserved.
//

import UIKit
class ViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var pageControl: UIPageControl!
    var imageArray = [UIImage]()
    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Do any additional setup after loading the view.
        imageArray.append(UIImage(named: "pic1.png")!)
        imageArray.append(UIImage(named: "pic2.png")!)
        imageArray.append(UIImage(named: "pic3.png")!)
        imageArray.append(UIImage(named: "pic4.png")!)
        pageControl.hidesForSinglePage = true
              self.pageControl.numberOfPages = self.imageArray.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
       }
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
             let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionCellView
      
        cell.introImage.image = imageArray[indexPath.row]
        return cell
       }
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
                  return CGSize(width: self.collectionView.frame.width, height: self.collectionView.frame.height)
              }
                  
              func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
                  return 0
              }

              func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
                  return 0
              }
    @IBAction func PageCtrlAction(_ sender: UIPageControl) {
                     //get cell size
          let cellSize = view.frame.size
          //get current content Offset of the Collection view
          let contentOffset = collectionView.contentOffset
          if collectionView.contentSize.width <= collectionView.contentOffset.x + cellSize.width
          {
              print("\(cellSize.width) == \(cellSize.height)")
              let r = CGRect(x: 0, y: contentOffset.y, width: cellSize.width, height: cellSize.height)
              collectionView.scrollRectToVisible(r, animated: true)

          } else {
              print("\( cellSize.height) == \(cellSize.height)")

              let r = CGRect(x: contentOffset.x + cellSize.width, y: contentOffset.y, width: cellSize.width, height: cellSize.height)

              collectionView.scrollRectToVisible(r, animated: true);
          }
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
               let visibleRect = CGRect(origin: self.collectionView.contentOffset, size: self.collectionView.bounds.size)
               let visiblePoint = CGPoint(x: visibleRect.midX, y: visibleRect.midY)
               if let visibleIndexPath = self.collectionView.indexPathForItem(at: visiblePoint) {
                   self.pageControl.currentPage = visibleIndexPath.row
               }
           }
    override public var supportedInterfaceOrientations: UIInterfaceOrientationMask {
       return .landscapeRight
     }
     override public var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
       return .landscapeRight
     }
}

